import '../src/styles/App.css';
import Pokemon from './components/Pokemon';
import React, {useState} from 'react';


const pokemons = [
    {
      name: "bulbasaur",
      id: "1"
    },
    {
      name: "ivysaur",
      id: "2"
    },
    {
      name: "venusaur",
      id: "3"
    },
    {
      name: "charmander",
      id: "4"
    },
    {
      name: "charmeleon",
      id: "5"
    },
    {
      name: "charizard",
      id: "6",
    },
    {
      name: "squirtle",
      id: "7",
    },
    {
      name: "wartortle",
      id: "8",
    },
    {
      name: "blastoise",
      id: "9",
    },
    {
      name: "caterpie",
      id: "10",
    },
    {
      name: "metapod",
      id: "11",

    },
    {
      name: "butterfree",
      id: "12",
    },
    {
      name: "weedle",
      id: "13",

    },
    {
      name: "kakuna",
      id: "14",

    },
    {
      name: "beedrill",
      id: "15",
    },
    {
      name: "pidgey",
      id: "16",
    },
    {
      name: "pidgeotto",
      id: "17",
    },
    {
      name: "pidgeot",
      id: "18",
    },
    {
      name: "rattata",
      id: "19",

    },
    {
      name: "raticate",
      id: "20"
    }
  ]

const initialСatchPokemons =Object.fromEntries( pokemons.map(pokemon => {
  return [pokemon.id, false]
}))

initialСatchPokemons[2] = true
initialСatchPokemons[5] = true



//Сделать кнопку в App и при нажатии на кнопку вызывать функцию fetchPokemons и рисовать покемоно, которые пришли.  //12
//прочитать про offset/limit
//learnReact
function fetchPokemons() {
  return fetch("https://pokeapi.co/api/v2/pokemon/?offset=7&limit=12")
    .then(response => response.json())
    .then(data => {

      // "https://pokeapi.co/api/v2/pokemon/19/"
      return data.results.map(obj => {
        return {id : obj.url.slice(34, -1), name:obj.name}
      }
        )
    })

}

fetchPokemons().then(arr => {
  console.log(arr); // [{id, name}, {id, name}]
})


//Мы делаем копию объекта состояний, чтоюы данный оюъект гарантированно перерисовался
function App() {
  // const [countCatchP, setCountCatchP] = useState(0)
  const [catchPokemons, setCatchPokemons] = useState(initialСatchPokemons)

console.log(catchPokemons);

  function counter(id) {
    setCatchPokemons({
      ...catchPokemons,
      [id]: !catchPokemons[id],
    })
  }

  let counterCatchPokemons =  Object.values(catchPokemons).filter(value => value === true).length

  return (
    <div className='pokemons'>
      <h1 className='title'>Поймано покемонов</h1>
      <p className='counter'>{counterCatchPokemons}/{pokemons.length}</p>
      <div className='container-pokemons'>
        {pokemons.map(pokemon => 
          <Pokemon  togglePokemon={counter}  isCatch={catchPokemons[pokemon.id]} pokemon={pokemon} key={pokemon.id}/>
        )}
			</div>
      </div>
  );
}

export default App;
