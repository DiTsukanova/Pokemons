import React, {useState} from 'react';
import '../styles/Pokemons.css';


const Pokemon = ({pokemon, isCatch, togglePokemon}) => {
	// const {pokemon} = props;

	// const [isCatch, setIsCatch] = useState(false)
	// function catchPokemons() {
	// 	setIsCatch(!isCatch)
	// 	countCatchP(!isCatch)
	// }
	return (
		<div style={{backgroundColor: isCatch? 'red ': 'green'}} className='pokemon'>
			<p className="pokemon__name">{pokemon.name}</p>
			<img className='pokemon__image' width={96} height={96}  src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`} alt={pokemon.name} />
			<button onClick={() => togglePokemon(pokemon.id)}  className="pokemon__button">{isCatch ? 'Отпустить' : 'Поймать'}</button>
		</div>
	);
};

export default Pokemon;